// Thynkly LEADGEN (LIVE). Keeps a small queue of iDocs captures and today's dialer totals,
// and sends them to the CRM. Same ID on the same day is sent once.
// Sent captures are removed from the PC.
//
// Seat swapping (v1.1.0): agents swap PCs, so the person signed into the dialer decides whose work it is.
// - Every dialer count and every iDocs capture is stamped with the dialer username AT THE MOMENT it happens.
// - Totals are kept per dialer user, so Agent A's waiting counts stay A's after Agent B signs in.
// - Nobody signed into the dialer (or Guest / Admin) = the event is NOT counted for anyone (fail closed);
//   the popup shows how many were not counted.
// - The CRM finds the person from the username and checks they have their own seat; if not, it refuses and the
//   PC keeps the event and retries. The link code still proves the company.
// Every change to stored counts goes through one lock and re-reads storage, so a click that lands while a send
// is in progress is never overwritten.
const PRODUCT = { productCode: 'THYNKLY', modelCode: 'LEADGEN', environment: 'LIVE', version: chrome.runtime.getManifest().version };
const DEFAULT_CRM = '';
const MAX_QUEUE = 500;
const SEAT_FRESH_MS = 2 * 60000; // a hidden dialer tab still reports about once a minute
const KEEP_DAYS = 3; // the CRM accepts dialer days up to 3 days old
const CAPTURE_MAX_AGE_MS = 7 * 86400000; // the CRM refuses captures older than 7 days
const RETRY_REFUSED_MS = 10 * 60000;

const get = (k) => chrome.storage.local.get(k);
const set = (o) => chrome.storage.local.set(o);
const today = () => new Date().toISOString().slice(0, 10);
const validWho = (w) => !!(w && /^[A-Za-z0-9._@+-]{1,120}$/.test(String(w.user || '')) && ['DIALOG_CONNECT', 'VICIDIAL'].includes(w.source));
const newId = () => crypto.randomUUID();
const emailOf = (w) => (w && /^[^\s@<>"']{1,64}@[A-Za-z0-9.-]{1,190}$/.test(String(w.email || '')) ? String(w.email) : '');

// One lock for every read-change-write of stored counts.
let chain = Promise.resolve();
function locked(fn) { const run = chain.then(fn); chain = run.catch(() => {}); return run; }

async function hash(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
const installId = () => locked(async () => {
  const s = await get(['installId']);
  if (s.installId) return s.installId;
  const id = newId();
  await set({ installId: id });
  return id;
});
// Who is signed into the dialer on this PC right now (reported by the dialer tab).
async function currentSeat() {
  const s = (await get(['seat'])).seat;
  return s && validWho(s) && Date.now() - s.at < SEAT_FRESH_MS ? s : null;
}
const setSeat = (who, tabId) => locked(() => set({ seat: validWho(who) ? { source: who.source, user: who.user, email: emailOf(who), at: Date.now(), tabId } : null }));
const notCounted = (kind) => locked(async () => {
  const s = await get(['unassigned']);
  const day = today();
  const u = s.unassigned && s.unassigned.day === day ? s.unassigned : { day, idocs: 0, calls: 0 };
  u[kind] += 1;
  await set({ unassigned: u });
});

async function addCapture(rsaId, capturedAt) {
  const seat = await currentSeat();
  if (!seat) { await notCounted('idocs'); return; }
  const h = await hash(today() + ':' + seat.user.toLowerCase() + ':' + rsaId);
  const added = await locked(async () => {
    const s = await get(['queue', 'seenDay', 'seen', 'countDay', 'count']);
    const day = today();
    const seen = s.seenDay === day ? (s.seen || []) : [];
    if (seen.includes(h)) return false;
    seen.push(h);
    const queue = (s.queue || []).slice(-(MAX_QUEUE - 1));
    queue.push({ eid: newId(), type: 'idocsCapture', rsaId, capturedAt, source: 'IDOCS_QUICK_CAPTURE', dialerUser: seat.user, ...(emailOf(seat) ? { dialerEmail: emailOf(seat) } : {}), dialerSource: seat.source, ...PRODUCT });
    const count = (s.countDay === day ? (s.count || 0) : 0) + 1;
    await set({ queue, seenDay: day, seen, countDay: day, count });
    return true;
  });
  if (added) flush();
}

async function addDialer(event, label, who) {
  if (!validWho(who)) { if (event === 'call') await notCounted('calls'); return; }
  await locked(async () => {
    const s = await get(['dialers']);
    const day = today();
    const dialers = s.dialers || {};
    const key = who.source + '|' + who.user.toLowerCase() + '|' + day;
    const d = dialers[key] || { day, source: who.source, user: who.user, calls: 0, dispositions: 0, byDisposition: {} };
    if (emailOf(who)) d.email = emailOf(who);
    if (event === 'call') d.calls += 1;
    if (event === 'disposition') { d.dispositions += 1; d.byDisposition[label] = (d.byDisposition[label] || 0) + 1; }
    d.dirty = true;
    d.retryAt = 0;
    dialers[key] = d;
    await set({ dialers });
  });
}

async function post(url, key, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-LeadGen-Key': key }, body: JSON.stringify(body) }).catch(() => null);
  if (!r) return { ok: false, retry: true };
  const data = await r.json().catch(() => ({}));
  return { ok: r.ok, retry: !r.ok && (r.status >= 500 || r.status === 429), status: r.status, code: data.code || '', error: data.error || '' };
}

let flushing = false;
async function flush() {
  if (flushing) return;
  flushing = true;
  try {
    const s = await get(['crmUrl', 'key']);
    if (!s.key) return;
    
    // Fail closed: refuse stale saved lower-environment CRM addresses when upgrading.
    const crmOrigin = (() => {
      try {
        const candidate = new URL(String(s.crmUrl || ''));
        const host = candidate.hostname.toLowerCase();
        if (candidate.protocol !== 'https:' || candidate.username || candidate.password || candidate.port) return '';
        if (host === 'crm.thynkverse.co.za') return candidate.origin;
        if (/^[a-z0-9-]+\.crm\.thynkverse\.co\.za$/.test(host) && !/^(test|demo)\./.test(host)) return candidate.origin;
      } catch {}
      return '';
    })();
    if (!crmOrigin) return;
    const url = crmOrigin + '/api/thynkly/capture';
    // Check-in about every 5 minutes so the Supervisor sees 'Last active'.
    const hb = (await get(['lastBeat'])).lastBeat || 0;
    if (Date.now() - hb > 5 * 60000) {
      const r = await post(url, s.key, { type: 'heartbeat', ...PRODUCT });
      if (r.ok) await set({ lastBeat: Date.now() });
    }
    // Totals counted by v1.0.2 before the update: sent once the old way (no dialer user), then removed.
    // v1.1.0 never writes 'dialer', so nothing can be added to it meanwhile.
    const legacy = (await get(['dialer'])).dialer;
    if (legacy && legacy.dirty) {
      const summary = Object.entries(legacy.byDisposition || {}).map(([k, v]) => k + ': ' + v).join(', ');
      const r = await post(url, s.key, { type: 'dialerDay', day: legacy.day, callCount: legacy.calls, dispositionCount: legacy.dispositions, dispositionSummary: summary, source: 'DIALOG_CONNECT', ...PRODUCT });
      if (r.ok || !r.retry) await chrome.storage.local.remove('dialer');
    }

    // One total per dialer user per day per dialer. Send a snapshot; mark it sent only if nothing was added since.
    const id = await installId();
    const oldest = new Date(Date.now() - KEEP_DAYS * 86400000).toISOString().slice(0, 10);
    await locked(async () => {
      const dialers = (await get(['dialers'])).dialers || {};
      let pruned = false;
      for (const [k, d] of Object.entries(dialers)) if (d.day < oldest) { delete dialers[k]; pruned = true; }
      if (pruned) await set({ dialers });
    });
    const snapshot = (await get(['dialers'])).dialers || {};
    for (const [k, d] of Object.entries(snapshot)) {
      if (!d.dirty || (d.retryAt && d.retryAt > Date.now())) continue;
      const summary = Object.entries(d.byDisposition).map(([x, n]) => x + ': ' + n).join(', ');
      const r = await post(url, s.key, { type: 'dialerDay', day: d.day, callCount: d.calls, dispositionCount: d.dispositions, dispositionSummary: summary, source: d.source, dialerUser: d.user, ...(d.email ? { dialerEmail: d.email } : {}), installId: id, ...PRODUCT });
      if (r.retry) break;
      await locked(async () => {
        const dialers = (await get(['dialers'])).dialers || {};
        const cur = dialers[k];
        if (!cur) return;
        if (r.ok) { cur.error = ''; if (cur.calls === d.calls && cur.dispositions === d.dispositions) cur.dirty = false; }
        else { cur.error = r.code || String(r.status || ''); cur.retryAt = Date.now() + RETRY_REFUSED_MS; }
        await set({ dialers });
      });
    }

    // iDocs queue: each item goes to the person stamped on it. A refused item (e.g. dialer user not linked yet)
    // stays on the PC, waits 10 minutes and never blocks other people's items; a network/server error stops
    // until the next try. Items are found again by their own id, so new captures added meanwhile are kept.
    await locked(async () => {
      const queue = (await get(['queue'])).queue || [];
      const cutoff = Date.now() - CAPTURE_MAX_AGE_MS;
      const next = queue.filter((q) => !(Date.parse(q.capturedAt) < cutoff)).map((q) => (q.eid ? q : { ...q, eid: newId() }));
      await set({ queue: next });
    });
    const items = (await get(['queue'])).queue || [];
    for (const item of items) {
      if (item.retryAt && item.retryAt > Date.now()) continue;
      const { eid, retryAt, error, ...body } = item;
      const r = await post(url, s.key, body);
      if (r.retry) break;
      await locked(async () => {
        const queue = (await get(['queue'])).queue || [];
        const i = queue.findIndex((q) => q.eid === eid);
        if (i < 0) return;
        if (r.ok) { queue.splice(i, 1); await set({ queue, lastSentAt: new Date().toISOString() }); }
        else { queue[i] = { ...queue[i], retryAt: Date.now() + RETRY_REFUSED_MS, error: r.code || String(r.status || '') }; await set({ queue }); }
      });
    }
    const left = (await get(['queue'])).queue || [];
    const refused = left.find((q) => q.error);
    await set({ queueError: refused ? refused.error : '' });
  } finally {
    flushing = false;
  }
}

// A click waits 4 s; if the page did not report an error, it counts.
const pending = new Map();
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === 'pending') {
    pending.set(msg.token, msg);
    setTimeout(() => { const p = pending.get(msg.token); pending.delete(msg.token); if (p) addCapture(p.rsaId, p.capturedAt); }, 4000);
  }
  if (msg && msg.type === 'cancel') pending.delete(msg.token);
  if (msg && msg.type === 'dialer') addDialer(msg.event, msg.label, msg.who);
  if (msg && msg.type === 'seat') setSeat(msg.who, sender && sender.tab ? sender.tab.id : null);
  if (msg && msg.type === 'flush') flush().then(() => reply({ ok: true }));
  return msg && msg.type === 'flush';
});
// The dialer tab was closed: nobody is signed in on this PC any more.
if (chrome.tabs && chrome.tabs.onRemoved) {
  chrome.tabs.onRemoved.addListener((tabId) => locked(async () => {
    const seat = (await get(['seat'])).seat;
    if (seat && seat.tabId === tabId) await set({ seat: null });
  }));
}
chrome.alarms.create('flush', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'flush') flush(); });
