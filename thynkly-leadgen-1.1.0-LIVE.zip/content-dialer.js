// Thynkly LEADGEN: loads on every Dialog Connect page. The dialer moves between pages
// (/dialercampaign, /agent, /v2 ...) without reloading, so it counts on every page except sign-in.
// Counts (v1.0.1):
// - a call when the Lead Gen clicks Hangup;
// - if no Hangup was clicked (the client hung up, or the dialer has no Hangup button),
//   the call is counted once when the result is saved: every saved result = one call ended;
// - a result (disposition) when they pick one (CALLBACK, DID NOT QUALIFY, DROP, ...) and then
//   click Save or Update Lead. Picking a result and clicking both Save and Update Lead counts once.
// No phone numbers or lead details are read.
//
// Seat swapping (v1.1.0): every count carries WHO is signed into Dialog Connect right now, so the CRM credits
// that person, not whoever linked this PC. Only 'agent' sessions count (never Guest, Admin or signed out).
// From the page's own 'userData' record we keep ONLY username, sign-in email, role and expiry (agents sign in with
// their email; the Supervisor may have entered either). The record also holds a phone
// password and there is a session token next to it: neither is ever kept, stored or sent.
(function () {
  let chosen = '';
  let hungUp = false;
  const signIn = () => /sign-?in/i.test(location.pathname);
  const label = (el) => ((el && (el.textContent || el.getAttribute('aria-label'))) || '').replace(/\s+/g, ' ').trim().toUpperCase();

  // Who is signed in: username from userData, role must be agent, session not expired, and the name in the
  // top bar must match the record (a stale record never counts). Anything else = nobody (fail closed).
  function who() {
    if (signIn()) return null;
    try {
      const u = JSON.parse(localStorage.getItem('userData') || 'null');
      if (!u || typeof u !== 'object' || !u.data) return null;
      const role = String(u.role || '').trim().toLowerCase();
      const user = String(u.data.username || '').trim();
      const name = String(u.data.displayName || '').trim();
      const email = String(u.data.email || '').trim();
      const exp = Number(u.exp) || 0;
      if (role !== 'agent' || !/^[A-Za-z0-9._@+-]{1,120}$/.test(user)) return null;
      if (exp && exp * 1000 <= Date.now()) return null;
      const bar = document.querySelector('.MuiAppBar-root span.MuiTypography-root');
      if (!bar || !name || bar.textContent.trim() !== name) return null;
      return { source: 'DIALOG_CONNECT', user, ...(/^[^\s@<>"']{1,64}@[A-Za-z0-9.-]{1,190}$/.test(email) ? { email } : {}) };
    } catch { return null; }
  }
  const send = (msg) => chrome.runtime.sendMessage({ ...msg, who: who() });
  // Tell the extension who is signed in (for iDocs captures on this PC), on load and every 15 seconds.
  // Also right away when the page is shown or hidden, another tab signs in/out, and nobody when this page closes.
  const report = (gone) => { try { chrome.runtime.sendMessage({ type: 'seat', who: gone === true ? null : who() }); } catch {} };
  report();
  setInterval(report, 15000);
  document.addEventListener('visibilitychange', () => report());
  window.addEventListener('storage', () => report());
  window.addEventListener('pagehide', () => report(true));

  document.addEventListener('click', (e) => {
    if (signIn()) return;
    const t = e.target && e.target.closest ? e.target : null;
    if (!t) return;
    const btn = t.closest('button, [role="button"]');
    if (t.closest('#hangup-button, [data-testid="CallEndIcon"]') || (btn && /^HANG ?UP( CALL)?$/.test(label(btn)))) {
      send({ type: 'dialer', event: 'call' });
      hungUp = true;
      return;
    }
    const opt = t.closest('[id^="disposition-dropdown-option-"]');
    if (opt) { chosen = label(opt).slice(0, 40); return; }
    const save = t.closest('#save-lead-button, div.MuiDialog-root button.MuiButton-contained');
    if (save && chosen) {
      if (!hungUp) send({ type: 'dialer', event: 'call' });
      send({ type: 'dialer', event: 'disposition', label: chosen });
      chosen = '';
      hungUp = false;
    }
  }, true);
})();
