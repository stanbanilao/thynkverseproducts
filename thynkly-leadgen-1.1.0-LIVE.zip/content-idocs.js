// Runs only on the iDocs Quick Capture form (rapidForm.xhtml).
// On a button click: if the form has a valid SA ID and Terms & Conditions is ticked,
// tell the background right away (pending). If iDocs shows an error ~2 s later, cancel it.
// If iDocs moves to another page, the pending capture is kept.
(function () {
  function validSaId(v) {
    if (!/^\d{13}$/.test(v)) return false;
    const mm = Number(v.slice(2, 4)), dd = Number(v.slice(4, 6));
    if (mm < 1 || mm > 12 || dd < 1 || dd > 31) return false;
    let sum = 0;
    for (let i = 0; i < 13; i++) {
      let d = Number(v[12 - i]);
      if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
      sum += d;
    }
    return sum % 10 === 0;
  }
  function findId() {
    for (const el of document.querySelectorAll('input')) {
      const v = String(el.value || '').replace(/\s+/g, '');
      if (validSaId(v)) return v;
    }
    return '';
  }
  function termsTicked() {
    if ([...document.querySelectorAll('input[type=checkbox]')].some((c) => c.checked)) return true;
    return !!document.querySelector('.ui-chkbox-box.ui-state-active, .ui-chkbox-icon.ui-icon-check');
  }
  function errorShown() {
    return [...document.querySelectorAll('.ui-messages-error, .ui-message-error, .ui-growl-item-container.ui-state-error')]
      .some((e) => e.offsetParent !== null);
  }
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('button, .ui-button, input[type=submit]');
    if (!btn) return;
    const id = findId();
    if (!id || !termsTicked()) return;
    const token = Date.now() + ':' + Math.random();
    chrome.runtime.sendMessage({ type: 'pending', token, rsaId: id, capturedAt: new Date().toISOString() });
    setTimeout(() => { if (errorShown()) chrome.runtime.sendMessage({ type: 'cancel', token }); }, 2000);
  }, true);
})();
