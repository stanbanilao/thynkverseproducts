const $ = (id) => document.getElementById(id);
const today = () => new Date().toISOString().slice(0, 10);

// LIVE package: the link code is sent only to a licensed company CRM.
// LIVE destination: the company-provided CRM domain.
function crmAddress(value) {
  let v = String(value || '').trim();
  if (!v) return '';
  if (!/^https?:\/\//i.test(v)) v = 'https://' + v;
  try {
    const u = new URL(v);
    const host = u.hostname.toLowerCase();
    if (u.protocol !== 'https:' || u.username || u.password || u.port) return '';
    if (host !== 'crm.thynkverse.co.za' && (!/^[a-z0-9-]+\.crm\.thynkverse\.co\.za$/.test(host) || /^(test|demo)\./.test(host))) return '';
    return 'https://' + host;
  } catch { return ''; }
}

// Seat swapping (v1.1.0): the person signed into the dialer decides whose work it is.
const SEAT_FRESH_MS = 3 * 60000;
const MESSAGES = {
  DIALER_USER_NOT_MAPPED: 'This dialer user is not linked to anyone. Ask your supervisor.',
  DIALER_USER_AMBIGUOUS: 'This dialer user is linked to more than one person. Ask your supervisor.',
  NO_ACTIVE_SEAT: 'No active Thynkly seat. Ask your supervisor for a link code.',
};
async function checkSeat(s, seat) {
  const crm = crmAddress(s.crmUrl);
  if (!s.key || !seat || !crm) { $('seatMsg').textContent = ''; return; }
  try {
    const r = await fetch(crm + '/api/thynkly/capture?check=1', { headers: { 'X-LeadGen-Key': s.key, 'X-Dialer-User': seat.user, ...(seat.email ? { 'X-Dialer-Email': seat.email } : {}) } });
    const d = await r.json().catch(() => ({}));
    if (r.ok && d.ok && d.person) { $('seat').textContent = d.person.name + ' · ' + d.person.type; $('seatMsg').textContent = ''; }
    else $('seatMsg').textContent = MESSAGES[d.code] || 'Could not check the dialer user.';
  } catch { $('seatMsg').textContent = 'Could not reach the CRM.'; }
}

async function render() {
  $('version').textContent = 'v' + chrome.runtime.getManifest().version;
  const s = await chrome.storage.local.get(['key', 'crmUrl', 'name', 'countDay', 'count', 'queue', 'lastSentAt', 'dialers', 'seat', 'unassigned']);
  const seat = s.seat && Date.now() - s.seat.at < SEAT_FRESH_MS ? s.seat : null;
  $('seat').textContent = seat ? seat.user : 'No dialer sign-in';
  const mine = Object.values(s.dialers || {}).filter((d) => d.day === today() && seat && d.source === seat.source && d.user.toLowerCase() === seat.user.toLowerCase());
  const dl = mine[0] || { calls: 0, dispositions: 0 };
  const un = s.unassigned && s.unassigned.day === today() ? s.unassigned : { idocs: 0, calls: 0 };
  $('unassigned').textContent = un.idocs + un.calls;
  $('calls').textContent = dl.calls;
  $('dispos').textContent = dl.dispositions;
  $('breakdown').textContent = Object.entries(dl.byDisposition || {}).map(([k, n]) => k + ' ' + n).join(' · ');
  const linked = !!s.key;
  $('linked').hidden = !linked; $('setup').hidden = linked;
  $('who').textContent = linked ? (s.name || 'Linked') : 'Not linked';
  $('count').textContent = s.countDay === today() ? (s.count || 0) : 0;
  $('pending').textContent = (s.queue || []).length;
  $('last').textContent = s.lastSentAt ? new Date(s.lastSentAt).toLocaleTimeString() : 'never';
  checkSeat(s, seat);
}

$('link').onclick = async () => {
  const key = $('code').value.trim();
  const crmUrl = crmAddress($('crm').value);
  $('msg').textContent = '';
  if (!key) { $('msg').textContent = 'Enter the link code from your supervisor.'; return; }
  if (!crmUrl) { $('msg').textContent = 'Enter the CRM address provided by your company.'; return; }
  try {
    const r = await fetch(crmUrl + '/api/thynkly/capture?check=1', { headers: { 'X-LeadGen-Key': key } });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.ok) { $('msg').textContent = 'Link code not accepted. Check it with your supervisor.'; return; }
    await chrome.storage.local.set({ key, crmUrl, name: d.name || '' });
    render();
  } catch {
    $('msg').textContent = 'Could not reach the CRM. Check the internet connection.';
  }
};
$('send').onclick = () => chrome.runtime.sendMessage({ type: 'flush' }, render);
render();
