<#
 Thynkverse Veyon CLIENT installer (TEST build)
 - Installs Veyon silently in client-only mode (no Master)
 - Imports the OfficeAdmin PUBLIC key (the private key never leaves the master PC)
 - Makes sure Veyon's firewall rule exists and the service is running
 - Applies website blocking from blocklist.txt (hosts file), if the list has entries
 Run via Install-Veyon-Client.cmd (right-click > Run as administrator not required, it elevates itself).
#>
param(
    [string]$InstallerPath = "",          # optional: path to a Veyon setup .exe (offline install)
    [string]$KeyName       = "OfficeAdmin", # must match the key name on the master PC
    [switch]$SkipBlocking,
    [string]$DnsServer     = "192.168.20.27", # AdGuard Home on the master PC
    [switch]$SkipDns,                          # do not touch DNS / browser Secure DNS
    [switch]$RestoreDns                        # undo: put DNS back to automatic (DHCP) and exit
)
$ErrorActionPreference = 'Stop'

# --- self-elevate ---
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $argList = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -KeyName `"$KeyName`""
    if ($InstallerPath) { $argList += " -InstallerPath `"$InstallerPath`"" }
    if ($SkipBlocking)  { $argList += " -SkipBlocking" }
    if ($SkipDns)       { $argList += " -SkipDns" }
    if ($RestoreDns)    { $argList += " -RestoreDns" }
    if ($DnsServer)     { $argList += " -DnsServer `"$DnsServer`"" }
    Start-Process powershell.exe -Verb RunAs -ArgumentList $argList
    exit
}

$here   = $PSScriptRoot
$logDir = Join-Path $env:ProgramData 'Thynkverse'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
Start-Transcript -Path (Join-Path $logDir 'veyon-install.log') -Append | Out-Null

if ($RestoreDns) {
    Get-NetAdapter | Where-Object { $_.Status -eq 'Up' } | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses }
    Clear-DnsClientCache
    Write-Host "DNS restored to automatic on all active adapters."
    Stop-Transcript | Out-Null; exit 0
}

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $keyFile = Join-Path $here "${KeyName}_public_key.pem"
    if (-not (Test-Path $keyFile)) { throw "Public key not found: $keyFile (extract the whole zip first)" }
    if ((Get-Content $keyFile -Raw) -match 'PRIVATE KEY') { throw "That file is a PRIVATE key. Stop. Use the public key only." }

    # --- 1. get the Veyon installer ---
    $setup = $InstallerPath
    if (-not $setup) {
        $local = Get-ChildItem -Path $here -Filter 'veyon*setup*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($local) { $setup = $local.FullName }
    }
    if (-not $setup) {
        Write-Host "No local Veyon installer found. Trying to download the latest release from GitHub..."
        $attempt = 0; $lastErr = $null
        while ($attempt -lt 3 -and -not $setup) {
            $attempt++
            try {
                $rel   = Invoke-RestMethod -Uri 'https://api.github.com/repos/veyon/veyon/releases/latest' -Headers @{ 'User-Agent' = 'thynkverse-veyon-deploy' } -TimeoutSec 30
                $asset = $rel.assets | Where-Object { $_.name -like '*win64-setup.exe' } | Select-Object -First 1
                if (-not $asset) { throw "Could not find a win64 setup in the latest Veyon release." }
                $tmp = Join-Path $env:TEMP $asset.name
                Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $tmp -UseBasicParsing -TimeoutSec 120
                $setup = $tmp
                Write-Host "Downloaded $($asset.name) (attempt $attempt)"
            } catch {
                $lastErr = $_.Exception.Message
                Write-Host "Download attempt $attempt failed: $lastErr"
                if ($attempt -lt 3) { Start-Sleep -Seconds (5 * $attempt) }
            }
        }
        if (-not $setup) {
            throw "Could not download Veyon after 3 attempts (last error: $lastErr). FIX: download the Windows 64-bit installer yourself from veyon.io/downloads or github.com/veyon/veyon/releases/latest, put the file in this same folder, then run Install-Veyon-Client.cmd again -- it will use that file automatically."
        }
    }
    $sig = Get-AuthenticodeSignature $setup
    Write-Host "Installer signature: $($sig.Status)   SHA256: $((Get-FileHash $setup -Algorithm SHA256).Hash)"
    if ($sig.Status -in 'HashMismatch','NotTrusted') { throw "Installer signature is $($sig.Status). Aborting." }

    # --- 2. silent install, client only ---
    Write-Host "Installing Veyon (silent, no Master)..."
    $p = Start-Process -FilePath $setup -ArgumentList '/S','/NoMaster' -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "Veyon installer exit code $($p.ExitCode)" }

    $cli = Join-Path $env:ProgramFiles 'Veyon\veyon-cli.exe'
    if (-not (Test-Path $cli)) { throw "veyon-cli.exe not found after install." }

    # --- 3. import the public key ---
    $keys = (& $cli authkeys list) -join "`n"
    if ($keys -match [regex]::Escape("$KeyName/public")) {
        Write-Host "Public key $KeyName/public is already installed. Skipping import."
    } else {
        Write-Host "Importing public key $KeyName/public ..."
        & $cli authkeys import "$KeyName/public" $keyFile 2>&1 | Out-Null
        $keys = (& $cli authkeys list) -join "`n"
        if ($keys -notmatch [regex]::Escape("$KeyName/public")) { throw "Key import failed. authkeys list:`n$keys" }
    }

    # --- 4. firewall + service ---
    if (-not (Get-NetFirewallRule -DisplayName 'Veyon*' -ErrorAction SilentlyContinue)) {
        Write-Host "Adding firewall rule for TCP 11100 (local subnet only)..."
        New-NetFirewallRule -DisplayName 'Veyon Service (Thynkverse)' -Direction Inbound -Protocol TCP -LocalPort 11100 -RemoteAddress LocalSubnet -Action Allow -Profile Any | Out-Null
    }
    & $cli service restart
    Start-Sleep -Seconds 3
    Write-Host ("Service status: " + ((& $cli service status) -join ' '))

    # --- 5. website blocking (hosts file) ---
    $blockFile = Join-Path $here 'blocklist.txt'
    if (-not $SkipBlocking -and (Test-Path $blockFile)) {
        $domains = Get-Content $blockFile | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ -and -not $_.StartsWith('#') } | Sort-Object -Unique
        $hosts = Join-Path $env:SystemRoot 'System32\drivers\etc\hosts'
        $begin = '# BEGIN THYNKVERSE-BLOCK'; $end = '# END THYNKVERSE-BLOCK'
        if (-not (Test-Path $hosts)) { New-Item -ItemType File -Force -Path $hosts | Out-Null }
        $text  = Get-Content $hosts -Raw
        if ($null -eq $text) { $text = "" }
        $text  = [regex]::Replace($text, "(?s)\r?\n?$([regex]::Escape($begin)).*?$([regex]::Escape($end))\r?\n?", "`r`n")
        if ($domains) {
            $lines = @($begin)
            foreach ($d in $domains) { $d = $d -replace '^www\.',''; $lines += "0.0.0.0 $d"; $lines += "0.0.0.0 www.$d" }
            $lines += $end
            $text = $text.TrimEnd() + "`r`n" + ($lines -join "`r`n") + "`r`n"
            Write-Host "Blocking $($domains.Count) site(s) via hosts file."
        } else { Write-Host "Blocklist is empty: nothing blocked." }
        Set-Content -Path $hosts -Value $text -Encoding ASCII
        ipconfig /flushdns | Out-Null
    }

    # --- 6. DNS -> AdGuard on the master + switch off browser Secure DNS ---
    # Wrapped so a problem here (network hiccup, registry quirk) is a warning,
    # not a failure that stops the whole install from finishing.
    try {
    if (-not $SkipDns) {
        # safety check: never switch DNS unless the AdGuard server really answers
        $ok = $false
        try { $null = Resolve-DnsName -Name 'example.com' -Server $DnsServer -DnsOnly -QuickTimeout -ErrorAction Stop; $ok = $true } catch {}
        if (-not $ok) {
            Write-Host "WARNING: $DnsServer did not answer DNS. DNS NOT changed (internet kept as is). Check AdGuard Home is running and port 53 is allowed in the master's firewall." -ForegroundColor Yellow
        } else {
            $adapters = Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' }
            $backup = @{}
            foreach ($a in $adapters) {
                $backup[$a.Name] = (Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4).ServerAddresses
                Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ServerAddresses $DnsServer
                Write-Host "DNS on '$($a.Name)' -> $DnsServer"
            }
            $backup | ConvertTo-Json | Set-Content (Join-Path $logDir 'dns-backup.json')
            Clear-DnsClientCache
        }

        # Chrome + Edge: Secure DNS off (policy, applies to all users)
        foreach ($k in 'HKLM:\SOFTWARE\Policies\Google\Chrome','HKLM:\SOFTWARE\Policies\Microsoft\Edge') {
            New-Item -Path $k -Force | Out-Null
            New-ItemProperty -Path $k -Name 'DnsOverHttpsMode' -Value 'off' -PropertyType String -Force | Out-Null
        }
        # Firefox: DNS over HTTPS off + locked (only if Firefox is installed)
        foreach ($ff in "$env:ProgramFiles\Mozilla Firefox","${env:ProgramFiles(x86)}\Mozilla Firefox") {
            if (Test-Path $ff) {
                $dist = Join-Path $ff 'distribution'; New-Item -ItemType Directory -Force -Path $dist | Out-Null
                '{"policies":{"DNSOverHTTPS":{"Enabled":false,"Locked":true}}}' | Set-Content (Join-Path $dist 'policies.json') -Encoding ASCII
            }
        }
        # Block DNS-over-TLS (port 853) so apps cannot bypass the filter
        if (-not (Get-NetFirewallRule -DisplayName 'Thynkverse Block DoT' -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule -DisplayName 'Thynkverse Block DoT' -Direction Outbound -Protocol TCP -RemotePort 853 -Action Block | Out-Null
        }
        Write-Host "Secure DNS switched off in Chrome/Edge/Firefox. Restart the browsers."
    }
    } catch {
        Write-Host "WARNING: DNS/Secure-DNS step hit a problem and was skipped: $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host "Veyon and website blocking above are NOT affected by this."
    }

    Write-Host "`nDONE. This PC can now be controlled from the master with key '$KeyName'."
    Write-Host "Log: $logDir\veyon-install.log"
    Stop-Transcript | Out-Null
    Write-Host "`nPress Enter to close this window..."
    Read-Host | Out-Null
    exit 0
}
catch {
    Write-Host "`nFAILED: $($_.Exception.Message)" -ForegroundColor Red
    Stop-Transcript | Out-Null
    Write-Host "`nPress Enter to close this window..."
    Read-Host | Out-Null
    exit 1
}
