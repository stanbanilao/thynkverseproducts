@echo off
rem Double-click me (after extracting the whole zip).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-client.ps1" %*
echo.
pause
