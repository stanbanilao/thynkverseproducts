<#
 Thynkverse Veyon CLIENT installer (TEST build)
 - Installs Veyon silently in client-only mode (no Master)
 - Imports the OfficeAdmin PUBLIC key (the private key never leaves the master PC)
 - Makes sure Veyon's firewall rule exists and the service is running
 - Applies website blocking from blocklist.txt (hosts file), if the list has entries
 Run via Install-Veyon-Client.cmd (right-click > Run as administrator not required, it elevates itself).
#>
param(
    [string]$InstallerPath = "",          # optional: path to a Veyon setup .exe (offline install)
    [string]$KeyName       = "OfficeAdmin", # must match the key name on the master PC
    [switch]$SkipBlocking
)
$ErrorActionPreference = 'Stop'

# --- self-elevate ---
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $argList = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -KeyName `"$KeyName`""
    if ($InstallerPath) { $argList += " -InstallerPath `"$InstallerPath`"" }
    if ($SkipBlocking)  { $argList += " -SkipBlocking" }
    Start-Process powershell.exe -Verb RunAs -ArgumentList $argList
    exit
}

$here   = $PSScriptRoot
$logDir = Join-Path $env:ProgramData 'Thynkverse'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
Start-Transcript -Path (Join-Path $logDir 'veyon-install.log') -Append | Out-Null

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $keyFile = Join-Path $here "${KeyName}_public_key.pem"
    if (-not (Test-Path $keyFile)) { throw "Public key not found: $keyFile (extract the whole zip first)" }
    if ((Get-Content $keyFile -Raw) -match 'PRIVATE KEY') { throw "That file is a PRIVATE key. Stop. Use the public key only." }

    # --- 1. get the Veyon installer ---
    $setup = $InstallerPath
    if (-not $setup) {
        $local = Get-ChildItem -Path $here -Filter 'veyon*setup*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($local) { $setup = $local.FullName }
    }
    if (-not $setup) {
        Write-Host "Downloading latest Veyon from the official GitHub releases..."
        $rel   = Invoke-RestMethod -Uri 'https://api.github.com/repos/veyon/veyon/releases/latest' -Headers @{ 'User-Agent' = 'thynkverse-veyon-deploy' }
        $asset = $rel.assets | Where-Object { $_.name -like '*win64-setup.exe' } | Select-Object -First 1
        if (-not $asset) { throw "Could not find a win64 setup in the latest Veyon release." }
        $setup = Join-Path $env:TEMP $asset.name
        Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $setup -UseBasicParsing
        Write-Host "Downloaded $($asset.name)"
    }
    $sig = Get-AuthenticodeSignature $setup
    Write-Host "Installer signature: $($sig.Status)   SHA256: $((Get-FileHash $setup -Algorithm SHA256).Hash)"
    if ($sig.Status -in 'HashMismatch','NotTrusted') { throw "Installer signature is $($sig.Status). Aborting." }

    # --- 2. silent install, client only ---
    Write-Host "Installing Veyon (silent, no Master)..."
    $p = Start-Process -FilePath $setup -ArgumentList '/S','/NoMaster' -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "Veyon installer exit code $($p.ExitCode)" }

    $cli = Join-Path $env:ProgramFiles 'Veyon\veyon-cli.exe'
    if (-not (Test-Path $cli)) { throw "veyon-cli.exe not found after install." }

    # --- 3. import the public key ---
    Write-Host "Importing public key $KeyName/public ..."
    & $cli authkeys import "$KeyName/public" $keyFile
    $keys = (& $cli authkeys list) -join "`n"
    if ($keys -notmatch [regex]::Escape("$KeyName/public")) { throw "Key import failed. authkeys list:`n$keys" }

    # --- 4. firewall + service ---
    if (-not (Get-NetFirewallRule -DisplayName 'Veyon*' -ErrorAction SilentlyContinue)) {
        Write-Host "Adding firewall rule for TCP 11100 (local subnet only)..."
        New-NetFirewallRule -DisplayName 'Veyon Service (Thynkverse)' -Direction Inbound -Protocol TCP -LocalPort 11100 -RemoteAddress LocalSubnet -Action Allow -Profile Any | Out-Null
    }
    & $cli service restart
    Start-Sleep -Seconds 3
    Write-Host ("Service status: " + ((& $cli service status) -join ' '))

    # --- 5. website blocking (hosts file) ---
    $blockFile = Join-Path $here 'blocklist.txt'
    if (-not $SkipBlocking -and (Test-Path $blockFile)) {
        $domains = Get-Content $blockFile | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ -and -not $_.StartsWith('#') } | Sort-Object -Unique
        $hosts = Join-Path $env:SystemRoot 'System32\drivers\etc\hosts'
        $begin = '# BEGIN THYNKVERSE-BLOCK'; $end = '# END THYNKVERSE-BLOCK'
        $text  = Get-Content $hosts -Raw
        $text  = [regex]::Replace($text, "(?s)\r?\n?$([regex]::Escape($begin)).*?$([regex]::Escape($end))\r?\n?", "`r`n")
        if ($domains) {
            $lines = @($begin)
            foreach ($d in $domains) { $d = $d -replace '^www\.',''; $lines += "0.0.0.0 $d"; $lines += "0.0.0.0 www.$d" }
            $lines += $end
            $text = $text.TrimEnd() + "`r`n" + ($lines -join "`r`n") + "`r`n"
            Write-Host "Blocking $($domains.Count) site(s) via hosts file."
        } else { Write-Host "Blocklist is empty: nothing blocked." }
        Set-Content -Path $hosts -Value $text -Encoding ASCII
        ipconfig /flushdns | Out-Null
    }

    Write-Host "`nDONE. This PC can now be controlled from the master with key '$KeyName'."
    Write-Host "Log: $logDir\veyon-install.log"
}
catch { Write-Host "`nFAILED: $($_.Exception.Message)" -ForegroundColor Red; Stop-Transcript | Out-Null; exit 1 }
Stop-Transcript | Out-Null
